---
wrapper_template: '_layouts/docs.html'
context:
  title: Reset | Base elements
---

# Reset

<hr>

Vanilla uses [Normalize](https://necolas.github.io/normalize.css/) to reset default browser styling on page elements. This helps remove any quirks or nuances specific to certain browsers before further styling is layered on top.
