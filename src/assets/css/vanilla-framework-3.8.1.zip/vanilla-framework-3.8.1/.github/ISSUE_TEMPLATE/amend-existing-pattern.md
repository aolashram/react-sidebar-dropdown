---
name: Amend existing pattern
about: This template allows users to propose an amendment to an existing pattern

---

## Pattern to amend

Add pattern name(s) here

## Visual

Provide a screenshot or link to a prototype of your pattern amendment.

## Context

In what context does your amendment solve a problem?
